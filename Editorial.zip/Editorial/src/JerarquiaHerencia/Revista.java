/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JerarquiaHerencia;

/**
 *
 * @author After
 */
public class Revista extends Publicaciones implements Periodicidad{
    private String ISSN;
    private String numero;

    public Revista() {
    }

    public String getIssn() {
        return ISSN;
    }

    public void setIssn(String ISSN) {
        this.ISSN = ISSN;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }
    
}
