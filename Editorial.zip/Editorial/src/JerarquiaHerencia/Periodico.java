/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JerarquiaHerencia;

/**
 *
 * @author After
 */
public class Periodico extends Publicaciones implements Periodicidad{
    private String editor;

    public Periodico() {
    }

    public String getEditor() {
        return editor;
    }

    public void setEditor(String editor) {
        this.editor = editor;
    }
    
}
