/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Publicaciones;
import java.util.ArrayList;

import JerarquiaHerencia.*;

/**
 *
 * @author After
 */
public class ManPublicaciones {
    static ArrayList<Publicaciones> arrPublica = new ArrayList<Publicaciones>();
    private Libro objLibro;
    private Revista objRevista;
    private Publicaciones objPublica;
    private Periodico objPeriodico;
    
    public ManPublicaciones() {
        
    }
    
    public ManPublicaciones(String titulo, double precio, int np){
        objPublica = new Publicaciones();
        objPublica.setTitulo(titulo);
        objPublica.setPrecio(precio);
        objPublica.setNoPaginas(np);
    }
    
    public void alta(String ISBN, String autor, String edicion){
        objLibro = new Libro();
        objLibro.setTitulo(objPublica.getTitulo());
        objLibro.setPrecio(objPublica.getPrecio());
        objLibro.setNoPaginas(objPublica.getNoPaginas());
        objLibro.setIsbn(ISBN);
        objLibro.setEdicion(edicion);
        objLibro.setAutor(autor);
        arrPublica.add(objLibro);
    }
    
    public void alta(String ISSN, String num){
        objRevista = new Revista();
        objRevista.setTitulo(objPublica.getTitulo());
        objRevista.setPrecio(objPublica.getPrecio());
        objRevista.setNoPaginas(objPublica.getNoPaginas());
        objRevista.setIssn(ISSN);
        objRevista.setNumero(num);
        arrPublica.add(objRevista);
    }
    
    public void alta(String editor){
        objPeriodico = new Periodico();
        objPeriodico.setTitulo(objPublica.getTitulo());
        objPeriodico.setPrecio(objPublica.getPrecio());
        objPeriodico.setNoPaginas(objPublica.getNoPaginas());
        objPeriodico.setEditor(editor);
        arrPublica.add(objPeriodico);
    }
    
    public ArrayList<Publicaciones> getList() {
        return arrPublica;
    }
    /*
    public void getList() {
        System.out.println("....Objetos en la publicacion....");
        Iterator<Publicaciones> itrPublica = arrPublica.iterator();
        while(itrPublica.hasNext()){
            Publicaciones publica = itrPublica.next();
            if(publica instanceof Libro){
                Libro book = new Libro();
                book = (Libro)publica;
                System.out.println("ISBN: " + book.getIsbn());
                System.out.println("Titulo: " + book.getTitulo());
            }
        }
    }
    */
}
